#include <stdio.h>
#include <stdlib.h>
#define CHAR_BITS  1  
#define INT_BITS  ( sizeof(int) * CHAR_BITS)

void PrintInBinary(unsigned n);
unsigned int ReverseTheBits(unsigned int num);

int main()
{
    unsigned int data = 0;
    unsigned int Rev = 0;
    
    printf("Enter the number : ");
    scanf("%u",&data);
    
    printf("\nBefore:" );
    PrintInBinary(data);
    
    
    Rev = ReverseTheBits(data);
   
    printf(" After:" );
    PrintInBinary(Rev);
    
return 0;
}

void PrintInBinary(unsigned n)
{
	short int x;
	
	for (x = (INT_BITS -1) ; x >= 0 ; x--)
	{
	  (n & (1 << x))? printf("1"): printf("0");	
	}
	
}

unsigned int ReverseTheBits(unsigned int n)
{
    unsigned int count = (INT_BITS -1); 
    unsigned int temp = n;       
    n >>= 1;
    
    while(n)
    {
       temp <<= 1;    
	      
       temp |= n & 1;
       
       n >>= 1; 
       
       count--;
    }
    
    temp <<= count; 
    
    return temp;
}
